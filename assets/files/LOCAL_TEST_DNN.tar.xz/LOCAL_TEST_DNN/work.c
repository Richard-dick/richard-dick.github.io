#include <assert.h>
#include <stdio.h>

static short _data[40960], _weight[40960], _result[40960];

#define FRAC_BIT 10

#define RD_ADDR _data
#define RD_SIZE_D0 1
#define RD_SIZE_D1 1
#define RD_SIZE_D2 28
#define RD_SIZE_D3 28

#define WEIGHT_ADDR _weight
#define WEIGHT_SIZE_D0 20
#define WEIGHT_SIZE_D1 1
#define WEIGHT_SIZE_D2 5
#define WEIGHT_SIZE_D3 5

#define WR_ADDR _result
#define WR_SIZE_D0 1
#define WR_SIZE_D1 20
#define WR_SIZE_D2 12
#define WR_SIZE_D3 12

#define KERN_ATTR_CONV_PAD 0
#define KERN_ATTR_CONV_STRIDE 1
#define KERN_ATTR_POOL_PAD 0
#define KERN_ATTR_POOL_KERN_SIZE 2
#define KERN_ATTR_POOL_STRIDE 2

struct size_vec4
{
	unsigned d0;
	unsigned d1;
	unsigned d2;
	unsigned d3;
};

struct mem_addr
{
	void *rd_addr;
	void *weight_addr;
	void *wr_addr;
};

int mul(short a, short b) { return a * b; }
int div(int a, int b) { return a / b; }

struct mem_addr addr = {RD_ADDR, WEIGHT_ADDR, WR_ADDR};
struct size_vec4 rd_size = {RD_SIZE_D0, RD_SIZE_D1, RD_SIZE_D2, RD_SIZE_D3};
struct size_vec4 wr_size = {WR_SIZE_D0, WR_SIZE_D1, WR_SIZE_D2, WR_SIZE_D3};
struct size_vec4 weight_size = {WEIGHT_SIZE_D0, WEIGHT_SIZE_D1, WEIGHT_SIZE_D2, WEIGHT_SIZE_D3};

struct size_vec4 conv_size;


void convolution()
{
	short *in = (short *)addr.rd_addr;
	short *weight = (short *)addr.weight_addr;
	short *out = (short *)addr.wr_addr;

	unsigned output_offset = 0;
	unsigned input_offset = 0;

	unsigned input_fm_w = rd_size.d3;
	unsigned input_fm_h = rd_size.d2;

	unsigned pad = KERN_ATTR_CONV_PAD;
	unsigned pad_len = pad << 1;

	unsigned conv_out_w = rd_size.d3 - weight_size.d3 + pad_len;
	unsigned conv_out_h = rd_size.d2 - weight_size.d2 + pad_len;

	unsigned stride = KERN_ATTR_CONV_STRIDE;

	conv_out_w = div(conv_out_w, stride);
	conv_out_h = div(conv_out_h, stride);

	conv_out_w++;
	conv_out_h++;

	conv_size.d0 = wr_size.d0;
	conv_size.d1 = wr_size.d1;
	conv_size.d2 = conv_out_h;
	conv_size.d3 = conv_out_w;
	
	//todo// 
	int no, ni, x, y, kx, ky, iw, ih;
	int res;
	int sum = 0;
	int bias = 0;
	int bias_size = 1 + mul(weight_size.d2, weight_size.d3);
	int input_size = mul(input_fm_h, input_fm_w);
	for (no = 0; no < conv_size.d1; no++)//channel num of output
	{
		input_offset = 0;
		printf("no:%d bias:%d input_offset:%d output_offset:%d\n",no,bias,input_offset,output_offset);
		for (ni = 0; ni < rd_size.d1; ni++)//channel num of input
		{
			output_offset = mul(no, mul(conv_out_h,conv_out_w));
			for (y = 0; y < conv_size.d3; y++)//height size of output
			{
				for (x = 0; x < conv_size.d2; x++)//width size of output
				{
					if (ni == 0)
						out[output_offset + x] = weight[bias];
					for (ky = 0; ky < weight_size.d3; ky++)
					{
						for (kx = 0; kx < weight_size.d2; kx++)
						{
							iw = kx + mul(x, stride) - pad;
							ih = ky + mul(y, stride) - pad;
							if (!(iw<0 || ih<0 || iw>=input_fm_w || ih>=input_fm_h))
							{
								res = mul(in[input_offset + mul(ih, input_fm_w) + iw], weight[bias + 1 + mul(ky, weight_size.d3) + kx]);
								sum += res;
							}
						}
					}
					out[output_offset + x] += (short)(sum >> FRAC_BIT);
					sum = 0;
				}
				output_offset += conv_size.d3;//inc op_off every time finish in a row
			}
			input_offset += input_size;//inc ip_off every time finish a input image
			//inc bias off every time finish a input image
		}
		bias += bias_size;
		printf("no:%d bias:%d input_offset:%d output_offset:%d\n",no,bias,input_offset,output_offset);

	}
}

void pooling()
{
	short *out = (short *)addr.wr_addr;

	unsigned output_offset = 0;
	unsigned input_offset = 0;

	unsigned input_fm_w = conv_size.d3;
	unsigned input_fm_h = conv_size.d2;

	unsigned pad = KERN_ATTR_POOL_PAD;
	unsigned pad_len = pad << 1;

	unsigned pad_w_test = conv_size.d3 - KERN_ATTR_POOL_KERN_SIZE;
	unsigned pad_h_test = conv_size.d2 - KERN_ATTR_POOL_KERN_SIZE;

	unsigned pool_out_w = pad_w_test + pad_len;
	unsigned pool_out_h = pad_h_test + pad_len;

	unsigned stride = KERN_ATTR_POOL_STRIDE;

	unsigned pad_w_test_remain = pad_w_test - mul(div(pad_w_test, stride), stride);
	unsigned pad_h_test_remain = pad_h_test - mul(div(pad_h_test, stride), stride);

	pool_out_w = div(pool_out_w, stride);
	pool_out_h = div(pool_out_h, stride);
	pool_out_w++;
	pool_out_h++;

	if ((!pad) && (pad_w_test_remain || pad_h_test_remain))
	{
		pool_out_w++;
		pool_out_h++;
	}

	/*please put your code here*/
	int pool_size = mul(pool_out_h, pool_out_w);//pool_out_h * pool_out_w;
	int in_size = mul(input_fm_w, input_fm_h);//input_fm_w * input_fm_h;
	int col_stride, row_stride;
	int iw, ih;
	for(int pool_channel = 0; pool_channel < conv_size.d1; ++pool_channel)
	{
		int pool_in_offset = mul(pool_channel, in_size);
		int pool_offset = mul(pool_channel, pool_size);
		for(int pool_row = 0; pool_row < pool_out_h; ++pool_row)
		{
			row_stride = mul(pool_row, stride);//pool_row*stride;
			int row_offset = mul(pool_row, pool_out_w);
			for(int pool_col = 0; pool_col < pool_out_w; ++pool_col)
			{
				col_stride = mul(pool_col, stride);//pool_col*stride;
				short max = 0x8000;//确定最小值
				for(int po_row = 0; po_row < KERN_ATTR_POOL_KERN_SIZE; ++po_row)
				{
					ih = po_row + row_stride - pad;
					for(int po_col = 0; po_col < KERN_ATTR_POOL_KERN_SIZE; ++po_col)
					{
						
						iw = po_col + col_stride - pad;
						short temp;
						//如果是padding，则计算的iw和ih应该在外部。为0
						input_offset = iw + pool_in_offset + mul(ih, input_fm_w);//pool_channel*in_size + ih*input_fm_w + iw;
						temp = (iw<0 || ih<0 || iw>=input_fm_w || ih>=input_fm_h)?0:out[input_offset];
						//out[input_offset] = 0;
						max = (max > temp)?max:temp;
					}
				}
				output_offset = pool_offset + row_offset + pool_col;
				out[output_offset] = max;
			}
		}
	}
	return;
}

int main(int argc, char **argv)
{
	if( argc != 3)
	{
		printf("===============================\n");
		printf("ERROR!please input channel!!\n");
		printf("===============================\n");
		return 0;
	}
	
	int k = argv[1][0] - '0';
	if(k < 0 && k>24)
	{
		printf("===============================\n");
		printf("ERROR!please input correct channel!!\n");
		printf("===============================\n");
		return 0;
	}
	char c = argv[2][0];
	FILE *data_f = fopen("data/data.bin", "r");
	assert(data_f != NULL);
	fread(_data, sizeof(_data[0]), sizeof(_data) / sizeof(_data[0]), data_f);
	fclose(data_f);
	FILE *weight_f = fopen("data/weight.bin", "r");
	assert(weight_f != NULL);
	fread(_weight, sizeof(_weight[0]), sizeof(_weight) / sizeof(_weight[0]), weight_f);
	fclose(weight_f);

	short *out = (short *)addr.wr_addr;
	printf("starting convolution\n");
	convolution();
	printf("in convolution\n");
	for (int x = 0; x < 24; ++x)
	{
		for (int y = 0; y < 24; ++y)
			if(c=='D' || c == 'd') printf("%5hd ",*(out +k*576+ x * 24 + y));
			else printf("%4hx ",*(out +k*576+ x * 24 + y));
		printf("\n");printf("\n");
	}
		
	printf("starting pooling\n");
	pooling();
	for (int x = 0; x < 12; ++x)
	{
		for (int y = 0; y < 12; ++y)
			if(c=='D' || c == 'd') printf("%5hd ",*(out +k*144+ x * 12 + y));
			else printf("%4hx ",*(out +k*144+ x * 12 + y));
		printf("\n");printf("\n");
	}

	return 0;
}
